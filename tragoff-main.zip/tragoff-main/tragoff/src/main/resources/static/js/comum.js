function verificarLogin() {

    var usuarioId = localStorage.getItem("usuarioId");

    if (!usuarioId) {
        window.location.replace("login.html");
    }

}

function verificarLoginAdmin() {

    var adminId = localStorage.getItem("adminId");

    if (!adminId) {
        window.location.replace("admin-login.html");
    }

}

function sair() {

    localStorage.removeItem("usuarioId");
    localStorage.removeItem("usuarioNome");

    window.location.replace("index.html");

}

function sairAdmin() {

    localStorage.removeItem("adminId");

    window.location.replace("index.html");

}

function formatarDinheiro(valor) {

    return "R$ " + Number(valor).toFixed(2).replace(".", ",");

}

function formatarDataHora(valor) {

    if (!valor) {
        return "";
    }

    return new Date(valor).toLocaleString("pt-BR");

}

function formatarData(valor) {

    if (!valor) {
        return "";
    }

    return new Date(valor).toLocaleDateString("pt-BR");

}

function dataHoje() {

    var hoje = new Date();

    var ano = hoje.getFullYear();
    var mes = String(hoje.getMonth() + 1).padStart(2, "0");
    var dia = String(hoje.getDate()).padStart(2, "0");

    return ano + "-" + mes + "-" + dia;

}

function colocarDataHoraAtual(idCampo) {

    var campo = document.getElementById(idCampo);

    if (!campo) {
        return;
    }

    var agora = new Date();

    var ano = agora.getFullYear();
    var mes = String(agora.getMonth() + 1).padStart(2, "0");
    var dia = String(agora.getDate()).padStart(2, "0");
    var hora = String(agora.getHours()).padStart(2, "0");
    var minuto = String(agora.getMinutes()).padStart(2, "0");

    campo.value =
        ano + "-" +
        mes + "-" +
        dia + "T" +
        hora + ":" +
        minuto;

}

function pegarIdDaUrl() {

    var parametros = new URLSearchParams(
        window.location.search
    );

    return parametros.get("id");

}